<!DOCTYPE html>

<html lang="it">
  <head>
    <meta charset="UTF-8" />
    <title>Guess - Shop online</title>
	    <link rel="icon" type="immagini/png" href="immagini/favicon.png">
    <meta
      name="keywords"
      content="moda, uomo, donna, teen, bambino, accessori"
    />
    <meta name="description" content="Ecommerce del brand Guess" />
    <meta name="author" content="martina ballesio" />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

  </head>

  <body>
    <header>
      <a href="index.html">
        <img src="immagini/logo.svg" alt="logo" title="logo" id="logo" />
      </a>
    </header>

    <nav>
      <ul class="ul_menu">
        <li class="li_menu"><a href="index.html">Home</a></li>
        <li class="li_menu"><a href="uomo.html">Uomo</a></li>
        <li class="li_menu"><a href="donna.html">Donna</a></li>
        <li class="li_menu"><a href="bambino.html">Bambino</a></li>
        <li class="li_menu"><a href="offerte.html">Offerte</a></li>
      </ul>
    </nav>

    <article>
      <h1>Galleria immagini</h1>
      <section>
        <div class="container">
          <div class="galleria">
            <div class="left">
              <img src="immagini/felpa-bambino.jpg" />
            </div>
            <div class="right">
              <div class="image">
                <img src="immagini/felpa-bambino.jpg" alt="felpa bambino" />
              </div>
              <div class="image">
                <img src="immagini/felpa-donna.jpg" alt="felpa donna" />
              </div>
              <div class="image">
                <img src="immagini/felpa-uomo.jpg" alt="felpa uomo" />
              </div>
              <div class="image">
                <img src="immagini/maglietta-donna.jpg" alt="maglietta donna" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </article>

    <footer>
      <br />
      Guess Shop Online |
      <a href="faq.html" class="yellow"> Faq </a> |
      <a href="contatti.html" class="yellow"> Contatti </a>|
      <a href="galleria.html" class="yellow"> Galleria immagini </a><br />
      Sito web realizzato da Martina Ballesio
      <br />
    </footer>
  </body>
</html>