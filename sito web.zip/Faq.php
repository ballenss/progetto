<!DOCTYPE html>

<html lang="it">
    
    <head>
      <meta charset="UTF-8" />
      <title> Guess - Shop online</title>
	      <link rel="icon" type="immagini/png" href="immagini/favicon.png">
      <meta name="keywords" content="moda, uomo, donna, teen, bambino, accessori" />
      <meta name="description" content="Ecommerce del brand Guess" />
      <meta name="author" content="Martina Ballesio" />
      <link rel="stylesheet" type="text/css" href="style.css"/>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   </head>

    <body>
       
       <header> 
         <a href="index.html"> 
          <img src="immagini/logo.svg" alt="logo" title="logo" id="logo" >
         </a>
       </header>

       <nav>
         <ul class="ul_menu">
          <li class="li_menu"> <a href="uomo.html">Uomo</a> </li>
          <li class="li_menu"> <a href="donna.html">Donna</a> </li>
        <li class="li_menu"> <a href="bambino.html">Bambino</a> </li>
		  <li class="li_menu"> <a href="offerte.html">Offere</a> </li>
         </ul>
       </nav>


       <article>
          
          <section>
              <p>
			  <h1>Faq - podcast</h1>
			  <audio controls>
			  <souce src="audio/audio1.ogg" type="audio/ogg">
			  <souce src="audio/audio2.mp3" type="audio/mpeg">
			   </audio>
			   </p>
			   </br>
		   </section> 
			   
			 <section>
			   <p>
			   <h1>Faq - Videotutorial </h1>
			   <video width="320" height="240" controls>
			   <souce src="video/movie.mp4" type="video/mp4">
			   <souce src="video/movie.mov" type="video/mov">
			 </video>
			 </p>
			 </br>
			 </section> 
			   
			   
			 <section>   
			  <p>
			  <h1>Faq -  video - youtube<h1>
			  <iframe width="560" height="315" 
			  src="https://www.youtube.com/embed/7hVQA20a3jo?si=71s3DWnY-jc3LPzB" 
			  title="YouTube video player" frameborder="0" allow="accelerometer; 
			  autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
			  </p>
			  </br>
			  
			  
			  <p>
			  <h1> Faq - Mappa - Immagine </h1>
			  <img src="immagini/punti.jpg" alt="workplace" title="workplace" usemap="#workmap">
			  
			  <map name="workmap">
			  <area class="rect-b" shape="rect" coords="34,44,270,350" alt="guida donna" href="https://www.calvinklein.it/donna" target="_blank">
			 
			  <area shape="rect" coords="450,200,500,300" alt="guida uomo" href="https://www.calvinklein.it/uomo" target="_blank">
			  <area shape="circle" coords="337,300,44" alt="guida bambino" href= "https://www.calvinklein.it/bambinotarget=" target="_blank">
			  </map>
			  </p>
			  
			  
			  
          </section>
 

       </article>
       
<!--
       <aside>
          <h3>Consigli E Guide</h3>
          <ol>  
            <li class="guide">
             <a href="https://www.guess.eu/it-it/guess/donna/jeans?subcategory=Guess-Women-Jeans%234e83aff4-8e73-48ec-8809-738dd54894a0" target="_blank">
               Guida Alla Vestibilità del Denim Donna
             </a> 
            </li>
            <li class="guide">
             <a href="https://www.guess.eu/it-it/guess/uomo/jeans?subcategory=Guess-Men-Jeans%23b29b0e18-d97b-40c1-8faa-d98a5d295227&page=1" target="_blank">
               Guida Alla Vestibilità del Denim Uomo
             </a> 
            </li>
            <li class="guide">
             <a href="https://www.calvinklein.it/guida-cura-denim-it" target="_blank">
               Guida alla Cura del Denim 
             </a> 
            </li>
          </ol>
       </aside>

--->

       <footer>
           <br/>
           Guess Shop Online |
           <a href="faq.html"> Faq </a> | <a href="contatti.html"> Contatti </a><br/>
           Sito web realizzato da Martina Ballesio
           <br/>
       </footer>

    </body>

</html>