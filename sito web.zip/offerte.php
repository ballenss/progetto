<!DOCTYPE html>

<html lang="it">
    
    <head>
      <meta charset="UTF-8" />
      <title> Guess- Shop online</title>
	      <link rel="icon" type="immagini/png" href="immagini/favicon.png">
      <meta name="keywords" content="moda, uomo, donna, teen, bambino, accessori" />
      <meta name="description" content="Ecommerce del brand Guess" />
      <meta name="author" content="Martina Ballesio" />
      <link rel="stylesheet" type="text/css" href="style.css"/>
	  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>

    <body>
       
       <header> 
         <a href="index.html"> 
          <img src="immagini/logo.svg" alt="logo" title="logo" id="logo" >
         </a>
       </header>

       <nav>
         <ul class="ul_menu">
          <li class="li_menu"> <a href="uomo.html">Uomo</a> </li>
          <li class="li_menu"> <a href="donna.html">Donna</a> </li>
          <li class="li_menu"> <a href="bambino.html">Bambino</a> </li>
		  <li class="li_menu"> <strong>Offerte</strong> </li>
         </ul>
       </nav>


       <article>
          
          <section>
              <table class="tabella-offerte">
			    <tr> 
				<td colspan="2"><h3>Offerte Bambino</h3> </td>
				</tr>
				<tr> 
				<th class="titolo-tabella-offerte"> Articolo </th>
				<th class="titolo-tabella-offerte"> Prezzo </th>
				</tr> 
				<tr class="tr-tabella-offerte"> 
				<td class="td-tabella-offerte"> Felpa Bambino</td>
				<td class="td-tabella-offerte">25 € </td>
				</tr>
				<tr class="td-tabella-offerte">  
				<td class="td-tabella-offerte">  Jeans Bambino </td>
			<td class="td-tabella-offerte"> 30 € </td>	
			</tr> 
				<tr class="tr-tabella-offerte">
				<td class="td-tabella-offerte"> Maglietta bambino</td>
				<td class="td-tabella-offerte"> 15 € </td>
				</tr>
				
			  </table>
			  
			  <br /></br />
			  
			   <table class="tabella-offerte">
			    <tr> 
				<td colspan="2"<h3>Offerte Donna</h3> </td>
				</tr>
				<tr> 
				<th class="titolo-tabella-offerte"> Articolo </th>
				<th class="titolo-tabella-offerte"> Prezzo </th>
				</tr>
				<tr class="tr-tabella-offerte">
				<td class="td-tabella-offerte"> Felpa Donna</td>
				<td class="td-tabella-offerte"rowspan="3"> 35 € </td>
				</tr>
				<tr class="tr-tabella-offerte">
				<td class="td-tabella-offerte">  Jeans Donna </td>
				</tr> 
				<tr>
				<td class="td-tabella-offerte"> Maglietta Donna</td>
				</tr>
				
			  </table>
			  
			  <br> </br> 
			  
			  
			   <table class="tabella-offerte">
			    <tr> 
				<td colspan="2"<h3> Offerte Uomo </h3> </td>
				</tr>
				<tr> 
				<th class="titolo-tabella-offerte"> Articolo </th>
				<th class="titolo-tabella-offerte"> Prezzo </th>
				</tr>
				<tr> 
				<td class="td-tabella-offerte"> Felpa Uomo</td>
				<td class="td-tabella-offerte" rowspan="2"> 25 € </td>
				</tr>
				<tr class="tr-tabella-offerte">
				<td class="td-tabella-offerte">  Jeans Uomo </td>
				</tr> 
				<tr class="tr-tabella-offerte">
				<td class="td-tabella-offerte"> Maglietta Uomo</td>
				<td class="td-tabella-offerte"> 15 € </td>
				</tr>
				
			  </table>
			  
          </section>
 

       </article>
       

       <aside>
          <h3>Consigli E Guide</h3>
          <ol>  
            <li class="guide">
             <a href="https://www.guess.eu/it-it/guess/donna/jeans?subcategory=Guess-Women-Jeans%234e83aff4-8e73-48ec-8809-738dd54894a0" target="_blank">
               Guida Alla Vestibilità del Denim Donna
             </a> 
            </li>
            <li class="guide">
             <a href="https://www.guess.eu/it-it/guess/uomo/jeans?subcategory=Guess-Men-Jeans%23b29b0e18-d97b-40c1-8faa-d98a5d295227&page=1" target="_blank">
               Guida Alla Vestibilità del Denim Uomo
             </a> 
            </li>
            <li class="guide">
             <a href="https://www.guess.eu/it-it/denim-fit-guide.html?srsltid=AfmBOorHuaIx_eNLkN6xE4BxRtFSEySuwgMVm8gz9-Mzfcy0rkHWxd2h" target="_blank">
               Guida alla Cura del Denim 
             </a> 
            </li>
          </ol>
       </aside>



       <footer>
           <br/>
           Guess Shop Online |
          <a href="faq.html" class="yellow"> Faq </a> |
      <a href="contatti.html" class="yellow"> Contatti </a>|
      <a href="galleria.html" class="yellow"> Galleria immagini </a><br />
           Sito web realizzato da Martina Ballesio
           <br/>
       </footer>

    </body>

</html>